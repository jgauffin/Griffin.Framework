﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Griffin.Net
{
    /// <summary>
    /// Networking support. Allows you to easily build client/server applications.
    /// </summary>
    [CompilerGenerated]
    class NamespaceDoc
    {
    }
}
