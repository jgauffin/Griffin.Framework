using Griffin.Net.Buffers;

namespace Griffin.Net.Channels
{
    /// <summary>
    /// For channels that do not use SocketAsyncEventArgs.
    /// </summary>
    public class BufferSliceSocketBuffer : ISocketBuffer
    {

        /// <summary>
        /// Initializes a new instance of the <see cref="BufferSliceSocketBuffer"/> class.
        /// </summary>
        /// <param name="slice">The slice.</param>
        /// <param name="bytesTransferred">The bytes transferred.</param>
        public BufferSliceSocketBuffer(IBufferSlice slice, int bytesTransferred)
        {
            BytesTransferred = bytesTransferred;
            Capacity = slice.Capacity;
            Count = bytesTransferred;
            BaseOffset = slice.Offset;
            Offset = BaseOffset;
            Buffer = slice.Buffer;
        }

        /// <summary>
        /// Can be used to pass custom information to the completion delegate
        /// </summary>
        public object UserToken { get; set; }

        /// <summary>
        /// Amount of bytes transferred for the last completed IO operation
        /// </summary>
        public int BytesTransferred { get; private set; }

        /// <summary>
        /// Amount of bytes to send/process 
        /// </summary>
        /// <seealso cref="Offset" />
        public int Count { get; private set; }

        /// <summary>
        /// Allocated buffer size
        /// </summary>
        public int Capacity { get; private set; }

        /// <summary>
        /// IO Buffer
        /// </summary>
        public byte[] Buffer { get; private set; }

        public int BaseOffset { get; private set; }
        public int Offset { get; private set; }

        /// <summary>
        /// Reuse the previously specified buffer, but change the offset/count of the bytes to send.
        /// </summary>
        /// <param name="offset">Index of first byte to send</param>
        /// <param name="count">Amount of bytes to send</param>
        public void SetBuffer(int offset, int count)
        {
            Offset = offset;
            Count = count;
        }

        /// <summary>
        /// Assign a buffer to the structure
        /// </summary>
        /// <param name="buffer">Buffer to use</param>
        /// <param name="offset">Index of first byte to send</param>
        /// <param name="count">Amount of bytes to send</param>
        /// <param name="capacity">Total number of bytes allocated for this slices</param>
        public void SetBuffer(byte[] buffer, int offset, int count, int capacity)
        {
            Buffer = buffer;
            Offset = BaseOffset = offset;
            Count = count;
            Capacity = capacity;
        }

        /// <summary>
        /// Assign a buffer to the structure
        /// </summary>
        /// <param name="buffer">Buffer to use</param>
        /// <param name="offset">Index of first byte to send</param>
        /// <param name="count">Amount of bytes to send</param>
        /// <remarks>
        /// Capacity will be set to same as <c>count</c>.
        /// </remarks>
        public void SetBuffer(byte[] buffer, int offset, int count)
        {
            Buffer = buffer;
            Offset = BaseOffset = offset;
            Count = count;
            Capacity = count;
        }
    }
}