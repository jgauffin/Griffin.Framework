﻿using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading.Tasks;

namespace Griffin.Net.Channels
{
    public interface ICommunicationChannel
    {
        /// <summary>
        ///     Channel got disconnected
        /// </summary>
        DisconnectHandler Disconnected { get; set; }

        /// <summary>
        ///     Channel received a new message
        /// </summary>
        MessageHandler MessageReceived { get; set; }

        /// <summary>
        ///     Channel have sent a message
        /// </summary>
        MessageHandler MessageSent { get; set; }

        /// <summary>
        ///     Invoked if the decoder failes to handle an incoming message
        /// </summary>
        /// <remarks>
        ///     <para>
        ///         The handler MUST close the connection once a reply have been sent.
        ///     </para>
        /// </remarks>
        ChannelFailureHandler ChannelFailure { get; set; }

        /// <summary>
        ///     Checks if the channel is connected.
        /// </summary>
        bool IsConnected { get; }

        /// <summary>
        ///     Gets address of the connected end point.
        /// </summary>
        EndPoint RemoteEndpoint { get; }

        /// <summary>
        ///     Identity of this channel
        /// </summary>
        /// <remarks>
        ///     Must be unique within a server.
        /// </remarks>
        string ChannelId { get; }

        /// <summary>
        ///     Can be used to store information in the channel so that you can access it at later requests.
        /// </summary>
        /// <remarks>
        ///     <para>All data is lost when the channel is closed.</para>
        /// </remarks>
        IChannelData Data { get; }

        /// <summary>
        ///     Pre processes incoming bytes before they are passed to the message builder.
        /// </summary>
        /// <remarks>
        ///     <para>
        ///         Can be used if you for instance uses a custom authentication mechanism which requires to process incoming
        ///         bytes instead of deserialized messages.
        ///     </para>
        /// </remarks>
        BufferPreProcessorHandler BufferPreProcessor { get; set; }

        /// <summary>
        ///     Cleanup everything so that the channel can be reused.
        /// </summary>
        void Cleanup();

        /// <summary>
        ///     Send a new message
        /// </summary>
        /// <param name="message">Message to send</param>
        /// <remarks>
        ///     <para>
        ///         Outbound messages are enqueued and sent in order.
        ///     </para>
        ///     <para>
        ///         You may enqueue <c>byte[]</c> arrays or <see cref="Stream" />  objects. They will not be serialized but
        ///         sent directly with the transport protocol (like HTTP or MicroMsg).
        ///     </para>
        /// </remarks>
        void Send(object message);

        /// <summary>
        ///     Close channel
        /// </summary>
        void Close();

        /// <summary>
        ///     Close channel asynchronously
        /// </summary>
        /// <returns></returns>
        Task CloseAsync();

    }
}