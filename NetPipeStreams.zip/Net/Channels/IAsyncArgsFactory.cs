﻿namespace Griffin.Net.Channels
{
    public interface IAsyncArgsFactory
    {
        
    }
}