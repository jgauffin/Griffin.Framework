﻿using System;
using System.IO.Pipes;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using Griffin.Net.Buffers;

namespace Griffin.Net.Channels
{
    internal class NamedPipeChannel : ICommunicationChannel
    {
        private static readonly object CloseMessage = new object();
        private readonly SemaphoreSlim _closeEvent = new SemaphoreSlim(0, 1);
        private readonly IMessageDecoder _decoder;
        private readonly IMessageEncoder _encoder;
        private readonly IMessageQueue _outboundMessages = new MessageQueue();
        private readonly IBufferSlice _readSlice;
        private bool _connected;
        private object _currentOutboundMessage;
        private BufferSliceSocketBuffer _readSocketBuffer;
        private EmptyEndpoint _remoteEndPoint;
        private PipeStream _stream;
        private BufferSliceSocketBuffer _writeSocketBuffer;

        public NamedPipeChannel(IBufferSlice readSlice, IMessageEncoder encoder, IMessageDecoder decoder)
        {
            if (readSlice == null) throw new ArgumentNullException("readSlice");
            _readSlice = readSlice;

            _encoder = encoder;
            _decoder = decoder;
            _decoder.MessageReceived = OnMessageCompleted;

            MessageSent = (channel, message) => { };
            Disconnected = (channel, exception) => { };
            ChannelFailure = (channel, error) => HandleDisconnect(null);

            _remoteEndPoint = EmptyEndpoint.Instance;
            ChannelId = GuidFactory.Create().ToString();
            Data = new ChannelData();
        }

        public DisconnectHandler Disconnected { get; set; }
        public MessageHandler MessageReceived { get; set; }
        public MessageHandler MessageSent { get; set; }
        public ChannelFailureHandler ChannelFailure { get; set; }

        public bool IsConnected
        {
            get { return _stream != null && _stream.IsConnected; }
        }

        public EndPoint RemoteEndpoint { get; private set; }
        public string ChannelId { get; private set; }
        public IChannelData Data { get; private set; }
        public BufferPreProcessorHandler BufferPreProcessor { get; set; }

        public void Cleanup()
        {
            _encoder.Clear();
            _decoder.Clear();
            _currentOutboundMessage = null;
            try
            {
                _stream.Dispose();
            }
            catch
            {
            }
            _stream = null;
            _remoteEndPoint = EmptyEndpoint.Instance;
            _connected = false;
            if (_closeEvent.CurrentCount == 1)
                _closeEvent.Wait();

            if (Data != null)
                Data.Clear();

            object msg;
            while (_outboundMessages.TryDequeue(out msg))
            {
            }
        }

        public void Send(object message)
        {
            if (_stream != null)
                lock (_outboundMessages)
                {
                    if (_currentOutboundMessage != null)
                    {
                        _outboundMessages.Enqueue(message);
                        return;
                    }

                    _currentOutboundMessage = message;
                }

            SendCurrent();
        }

        /// <summary>
        /// Close channel
        /// </summary>
        public void Close()
        {
            Send(CloseMessage);
        }

        /// <summary>
        /// Called internally to be able to make sure that all messages have been sent properly
        /// </summary>
        internal void CloseNow()
        {
            try
            {
                _stream.WaitForPipeDrain();
            }
            catch
            {
                //eat since we are closing = best effort.
            }
            _stream.Dispose();
            _stream = null;
            _closeEvent.Release();
        }

        /// <summary>
        /// Close channel asynchronously
        /// </summary>
        /// <returns></returns>
        public async Task CloseAsync()
        {
            Send(CloseMessage);
            await _closeEvent.WaitAsync();
        }

        /// <summary>
        /// Assign an open pipe stream
        /// </summary>
        /// <param name="stream">The stream. It's recommended that the stream is configured to use <code>byte</code> mode for both writes and reads.</param>
        /// <exception cref="System.ArgumentNullException">stream</exception>
        public void Assign(PipeStream stream)
        {
            if (stream == null) throw new ArgumentNullException("stream");
            _stream = stream;
            _stream.BeginRead(_readSlice.Buffer, _readSlice.Offset, _readSlice.Capacity, OnRead, null);
        }

        private void HandleDisconnect(Exception sourceException)
        {
            try
            {
                _stream.Dispose();
                _connected = false;
                Disconnected(this, sourceException ?? new Exception("unknown reason"));
            }
            catch (Exception exception)
            {
                ChannelFailure(this, exception);
            }
        }

        private void OnMessageCompleted(object obj)
        {
            //TODO: Wrap to catch app exceptions
            MessageReceived(this, obj);
        }

        private void OnRead(IAsyncResult ar)
        {
            int bytesRead, offset = 0;
            try
            {
                bytesRead = _stream.EndRead(ar);
                if (bytesRead == 0)
                {
                    HandleDisconnect(null);
                    return;
                }

                if (BufferPreProcessor != null)
                {
                    var read = BufferPreProcessor(this, new BufferSliceSocketBuffer(_readSlice, bytesRead));
                    if (read > 0)
                    {
                        bytesRead -= read;
                        offset = read;
                    }
                }

                _readSocketBuffer.SetBuffer(offset, bytesRead);
            }
            catch (Exception x)
            {
                ChannelFailure(this, x);
                Cleanup();
                return;
            }

            try
            {
                // pre processor can have read everything
                if (bytesRead > 0)
                    _decoder.ProcessReadBytes(_readSocketBuffer);
            }
            catch (Exception exception)
            {
                ChannelFailure(this, exception);
                Cleanup();
                return;
            }

            try
            {
                _stream.BeginRead(_readSlice.Buffer, _readSlice.Offset, _readSlice.Capacity, OnRead, null);
            }
            catch (Exception x)
            {
                ChannelFailure(this, x);
                Cleanup();
            }
        }

        private void OnWriteCompleted(IAsyncResult ar)
        {
            try
            {
                _stream.EndWrite(ar);
                var isComplete = _encoder.OnSendCompleted(_writeSocketBuffer.Count);
                if (!isComplete)
                {
                    _encoder.Send(_writeSocketBuffer);
                    _stream.BeginWrite(_writeSocketBuffer.Buffer, _writeSocketBuffer.Offset, _writeSocketBuffer.Count,
                        OnWriteCompleted, null);
                    return;
                }
            }
            catch
            {
                return; // deal with it at the read side.
            }

            var msg = _currentOutboundMessage;
            lock (_outboundMessages)
            {
                if (!_outboundMessages.TryDequeue(out _currentOutboundMessage))
                {
                    _currentOutboundMessage = null;
                    MessageSent(this, msg);
                    return;
                }
            }

            MessageSent(this, msg);
            SendCurrent();
        }

        private void SendCurrent()
        {
            // Allows us to send everything before closing the connection.
            if (_currentOutboundMessage == CloseMessage)
            {
                try
                {
                    _currentOutboundMessage = null;
                    CloseNow();
                }
                catch (Exception e)
                {
                    HandleDisconnect(e);
                }
                return;
            }

            _encoder.Prepare(_currentOutboundMessage);
            _encoder.Send(_writeSocketBuffer);
            try
            {
                _stream.BeginWrite(_writeSocketBuffer.Buffer, _writeSocketBuffer.Offset, _writeSocketBuffer.Count,
                    OnWriteCompleted, null);
            }
            catch (Exception e)
            {
                HandleDisconnect(e);
            }
        }
    }
}