﻿using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading.Tasks;

namespace Griffin.Net.Channels
{
    /// <summary>
    ///     A channel is used to send and receive information over a socket.
    /// </summary>
    /// <remarks>
    ///     <para>
    ///         Channels should be designed so that they can be reused after a client have disconnected. Hence you have sure
    ///         that the state is cleared when the <c>Cleanup()</c> method is invoked. Buffers etc should still be used,
    ///         but any internal send queue etc should be emptied.
    ///     </para>
    /// </remarks>
    public interface ITcpChannel : ICommunicationChannel
    {
        /// <summary>
        ///     Assign a socket to this channel
        /// </summary>
        /// <param name="socket">Connected socket</param>
        /// <remarks>
        ///     the channel will start receive new messages as soon as you've called assign.
        /// </remarks>
        void Assign(Socket socket);
    }
}