﻿# Channels

Channels are the actual transport layer. Here are the classes which are used for communication defined.

Interesting classes:

* [TcpChannel](TcpChannel.cs)
* SecureTcpChannel
