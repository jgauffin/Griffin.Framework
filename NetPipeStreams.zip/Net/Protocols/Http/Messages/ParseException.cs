﻿using System;

namespace Griffin.Net.Protocols.Http.Messages
{
    public class ParseException : Exception
    {
        public ParseException(string errorMessage)
        {
            
        }
    }
}