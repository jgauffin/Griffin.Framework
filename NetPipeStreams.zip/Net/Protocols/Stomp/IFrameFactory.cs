﻿namespace Griffin.Net.Protocols.Stomp
{
    class IFrameFactory
    {
    }
}
