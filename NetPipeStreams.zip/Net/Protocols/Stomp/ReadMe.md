﻿# STOMP protocol implementation

Implements STOMP v1.2.

http://stomp.github.io/stomp-specification-1.2.html