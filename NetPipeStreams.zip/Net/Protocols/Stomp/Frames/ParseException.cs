﻿using System;

namespace Griffin.Net.Protocols.Stomp.Frames
{
    /// <summary>
    /// Failed to parse a header or similar.
    /// </summary>
    public class ParseException : Exception
    {
        
    }
}