﻿namespace Griffin.Net.Protocols.Stomp.Frames
{
    /// <summary>
    /// Parsed the frame name.
    /// </summary>
    /// <param name="name">name</param>
    public delegate void FrameNameHandler(string name);
}