﻿# Strings protocol

A trivial example to demonstrate how to create an encoder/decoder.

Fully operational and will transport strings over the network (with a binary length prefix).